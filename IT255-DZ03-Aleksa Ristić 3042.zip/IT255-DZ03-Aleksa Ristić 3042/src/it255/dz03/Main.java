
package it255.dz03;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import org.json.JSONObject;



public class Main {

    
   public static void main(String[] args) {
     try {
         Main.poziv();
        } catch (Exception e) {
         e.printStackTrace();
       }
     }
	   
public static void poziv() throws Exception {
     String url = "http://api.fixer.io/latest";
     URL obj = new URL(url);
     HttpURLConnection con = (HttpURLConnection) obj.openConnection();
     con.setRequestMethod("GET");
     con.setRequestProperty("User-Agent", "Mozilla/5.0");
     
     int responseCode = con.getResponseCode();
     
     System.out.println("\nSlanje 'GET' zahteva  URL-u : " + url);
     System.out.println("Response code : " + responseCode);
     
     BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
     String inputLine;
     StringBuffer response = new StringBuffer();
     while ((inputLine = br.readLine()) != null) {
     	response.append(inputLine);
     }
     br.close();
    
     
    JSONObject myresponse = new JSONObject(response.toString());
    
    System.out.println("PODACI O KURSEVIMA");
    System.out.println("Valuta-"+myresponse.getString("base"));
    System.out.println("Datum:"+myresponse.getString("date"));
    
    
    JSONObject rates_response = new JSONObject(myresponse.getJSONObject("rates").toString());
       
    System.out.println("Kursevi ="+ rates_response);
     
     }
     
     
     

   
}



        
